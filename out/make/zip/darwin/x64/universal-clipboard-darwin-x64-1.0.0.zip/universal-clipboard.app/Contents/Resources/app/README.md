_A project by Glen Chiacchieri and Geoffrey Litt for the Boston Stupid Hackathon 2020._

Have you ever wished you could share everything you copy-paste,
with everyone you know? Yeah, me too.

Your computer's copy-paste clipboard is behind the times.

It's not part of the social media ecosystem.

Use this tool to finally, after all this time, share your clipboard: with your friends, with the world.

Or something like that, TBD...
